// data.js
// red purple yellow orange black brown gray blue green
var LanguagePairEntry = `
comunicação	Kommunikation
	
Bom dia!	Guten Tag!
Bom dia!	Guten Morgen!
Boa noite!	Guten Abend!
Adeus!	Auf Wiedersehen!
Tchau!	Tschüss!
Até breve!	Bis bald!
Como vai?	Wie geht es Ihnen?
Obrigado, muito bom.	Danke, ganz gut.
	
Obrigado!	Danke!
Obrigado!	Vielen Dank!
Obrigado pela ajuda	Danke für die Hilfe
Por favor	Bitte
Sem problemas	Kein Problem
Desculpe-me, por favor!	Entschuldigen Sie bitte!
Desculpe.	Es tut mir leid.
	
Sim	Ja
Sim, claro	Ja, natürlich
Bom	Gut
Acordado	Einverstanden
Não	Nein
discordo	Ich bin nicht einverstanden
Não posso	Ich kann nicht
Isso é impossível	Das ist unmöglich
`;

// Подкаталог для MP3 файлов
var subdirectory = 'audio/';
