// data.js
// red purple yellow orange black brown gray blue green
var LanguagePairEntry = `
frente - atrás	vorne - hinten
fundo	hintergrund
primeiro plano	vordergrund
Em segundo plano	Im Hintergrund
Em primeiro plano	Im Vordergrund
pelo meio vemos...	in der Mitte sehen wir...
Desça - suba	runterGehen - hinaufGehen
sobre a ponte - debaixo da ponte	über die Brücke - unter der Brücke
vai e volta	hin - her
antes e depois	vorher und nachher
vantagens e desvantagens	Vorteile und Nachteile
Pontos fortes e fracos	Stärken und Schwächen
`;

// Подкаталог для MP3 файлов
var subdirectory = 'audio/Gegensatz/';
