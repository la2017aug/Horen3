// data.js
// red purple yellow orange black brown gray blue green
var LanguagePairEntry = `
Isso é ótimo!	Das ist toll!
Estou feliz!	Ich freue mich!
Estou feliz!	Freue mich!

Boa tarde, Sr. Weber. O meu nome é Igor Maltsev.	Guten Tag, Herr Weber. Ich heiße Igor Malzew.
Boa tarde, Sr. Maltsev. Muito agradável!	Guten Tag, Herr Malzew. Sehr angenehm!
Também!	Ebenfalls!

Ah, desculpe!	Oh, Verzeihung!
Sem problemas!	Keine Ursache!
Deixa lá.	Macht nichts.

Boa sorte!	Viel Glück!
Boa sorte!	Viel Erfolg!
Desejo-lhe um bom dia.	Ich wünsche dir noch einen schönen Tag.
Desejamos muito sucesso!	Wir wünschen Ihnen viel Erfolg!
Saúde!	Gesundheit!
As melhoras!	Gute besserung!
Parabéns!	Herzlichen Glückwunsch!

Como vai?	Wie geht es Ihnen?
Como está hoje?	Wie geht es dir heute?
obrigado, bom. E você?	danke gut. Und dir?
também bom, obrigado.	auch gut danke.

Estou feliz.	Ich bin glücklich.
Estou cansado.	Ich bin müde.
Eu estou doente.	Ich bin krank.
Estou constipado.	Ich bin erkältet.
Estou stressado.	Ich bin gestresst.
Estou chateado.	Ich bin sauer.
Estou triste.	Ich bin traurig.
Eu preciso de ajuda.	Ich brauche Hilfe.
Estou desapontado.	Ich bin enttäuscht.
`;

// Подкаталог для MP3 файлов
var subdirectory = 'audio/';
