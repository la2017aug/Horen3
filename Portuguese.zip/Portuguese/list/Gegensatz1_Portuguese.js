// data.js
// red purple yellow orange black brown gray blue green
var LanguagePairEntry = `
abrir - fechar	öffnen - schließen
aberto - fechado	geöffnet - geschlossen
ser - ser	auf sein - zu sein
abrir - fechar janela, porta, loja	aufmachen - zumachen Fenster, Tür, Laden
Abra os livros na página 7. Fecha os livros.	Öffnet ihr die Bücher auf Seite 7 . Schliesst ihr die Bücher.
As lojas do centro da cidade estão abertas a partir das 8h?	Sind die Geschäfte in der Innenstadt ab 8 Uhr auf?
Quando é que as lojas do centro da cidade fecham?	Wann sind die Geschäfte in der Innenstadt zu?
Abrem às 10h, mas as padarias abrem a partir das 7h.	Sie machen um 10 Uhr auf aber die Bäckereien sind ab 7 Uhr geöffnet.
às 19h	um 19 Uhr zu
encerrado às 21h	um 21 Uhr geschlossen
	
ligar - desligar dispositivos, eletricidade	einschalten - ausschalten Geräte, Strom
estar ligado - estar desligado	an sein - aus sein
ligar - desligar	anmachen - ausmachen
Ligue o computador e a impressora.	Schalte bitte den Computer und den Drucker ein.
Eles já estão ligados.	Sie sind schon an.
Por favor, apague as luzes.	Mach bitte das Licht aus.
	
aumentar - diminuir	aufdrehen - zudrehen
desligar	abdrehen
Desliguei a torneira.	Ich habe den Wasserhahn zugedreht.
A torneira principal está fechada.	Der Haupthahn ist abgedreht.
`;

// Подкаталог для MP3 файлов
var subdirectory = 'audio/Gegensatz/';
