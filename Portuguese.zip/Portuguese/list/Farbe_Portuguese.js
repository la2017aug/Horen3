// data.js
// red purple yellow orange black brown gray blue green
var LanguagePairEntry = `
azul	blau	
marrom	braun	
amarelo	gelb	
verde	grün	
roxo	lila	
laranja	orange	
rosa	pink	
rosa	rosa	
vermelho	rot	
preto	schwarz	
branco	weiß	
transparente	transparent	
brilhante	brillant	
espumante	funkelnd	

Conjuntos de cores.	Farbe Sätze.	red
ela está a usar jeans azuis.	sie trägt blaue Jeans.
ele experimenta calças castanhas.	er probiert braune Hosen an.
A parede está pintada de amarelo.	Die Wand ist gelb gestrichen.
Comprei botas verdes.	Ich habe grüne Stiefel gekauft.
ela tinha o cabelo roxo.	sie hatte lila Haare.
Um chapéu laranja está numa prateleira.	Ein orangefarbener Hut liegt auf einem Regal.
ela usava sapatos cor-de-rosa.	sie trug rosa Schuhe.
Ela entrou no carro cor-de-rosa.	sie stieg in rosa Auto ein.
Atravessei a rua num sinal vermelho.	Ich überquerte die Straße bei Rot.
Gato preto saltou para uma árvore.	Schwarze Katze sprang auf einen Baum.
Havia neve branca no chão.	Auf dem Boden lag weißer Schnee.
A água deste lago é tão transparente que se consegue ver o fundo.	Das Wasser in diesem See ist so transparent, dass man den Grund sehen kann.
O seu relógio tem um design brilhante.	Ihre Uhr hat ein brillant Design.
A corrente brilhante combina na perfeição com o seu vestido.	Die funkelnde Kette passt perfekt zu deinem Kleid.
O Mercedes roxo embateu numa árvore na estrada distrital de Selm, em outubro.	Der lilafarbener Mercedes krachte im Oktober gegen einen Baum am der Kreisstraße in Selm.
`;

// Подкаталог для MP3 файлов
var subdirectory = 'audio/';
