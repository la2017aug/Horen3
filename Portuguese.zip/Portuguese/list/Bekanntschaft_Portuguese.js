// data.js
// red purple yellow orange black brown gray blue green
var LanguagePairEntry = `
conhecido	Bekanntschaft
	
Qual o seu nome?	Wie heißen Sie?
Quem é você?	Wer bist du?
O meu nome é...	Ich heiße...
Eu sou...	Ich bin...
Muito agradável	Sehr angenehm
Nós não nos conhecemos	Wir kennen uns nicht
Conhece essa mulher?	Kennen Sie diese Frau?
	
o homem	der Mann
a mulher	die Frau
o adulto	der Erwachsene
a criança	das Kind
os jovens	der Junge
a menina	das Mädchen
	
Você é casado?	Sind Sie verheiratet?
Eu sou solteiro	Ich bin unverheiratet
Sou divorciado	Ich bin geschieden
Tem filhos?	Haben Sie Kinder?
Eu não tenho filhos	Ich habe keine Kinder
Quantos anos tem?	Wie alt sind Sie?
Quantos anos tem o seu filho?	Wie alt ist Ihr Sohn?
Tenho trinta anos	Ich bin dreißig Jahre alt
	
a família	die Familie
a mãe	die Mutter
o pai	der Vater
os pais	die Eltern
a esposa	die Ehefrau
o marido	der Ehemann
a filha	die Tochter
o filho	der Sohn
a irmã	die Schwester
o irmão	der Bruder
	
Qual é a sua ocupação?	Was sind Sie von Beruf?
Trabalha com o quê?	Was machen Sie beruflich?
Sou engenheiro	Ich bin Ingenieur
Onde trabalha?	Wo arbeiten Sie?
Eu trabalho num banco	Ich arbeite in einer Bank
Eu trabalho num hospital	Ich arbeite in einem Krankenhaus
eu não trabalho	Ich arbeite nicht
	
Funcionário	Angestellte
o advogado	der Anwalt
o trabalhador	der Arbeiter
o médico	der Arzt
o contador	der Buchhalter
o intérprete	der Dolmetscher
o empresário	der Geschäftsmann
o jornalista	der Journalist
o professor	der Lehrer
o programador	der Programmierer
o escritor	der Schriftsteller
o estudante	der Student
o vendedor	der Verkäufer
	
eu falo alemão	Ich spreche Deutsch
eu não falava inglês	Ich sprache Englisch nicht
Você entende-me?	Verstehen Sie mich?
Eu entendo	Ich verstehe
Por favor repita	Wiederholen Sie bitte
O que significa?	Was bedeutet das?
Preciso de um intérprete	Ich brauche einen Dolmetscher
`;

// Подкаталог для MP3 файлов
var subdirectory = 'audio/';
